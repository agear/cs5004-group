package expression;

import java.util.Map;

/**
 * Represents a node in an expression tree. Contains data in a string. Can be solved,
 * and represented in scheme or infix representation.
 */
public interface TreeNode {

  /** Calculates the result of the current node. If it's an operator, then it has to solve
   * by using its own value to compute the children. If it's an operand, then it returns
   * itself as a double.
   * @param variableValues The mapping between variables and values
   * @return result of evaluating current node arithmetically
   */
  double solve(Map<String, Double> variableValues);

  /** Returns the current node formatted in infix representation.
   * @return the current node formatted in infix representation
   */
  String infix();

  /** Returns the current node formatted in scheme representation.
   * @return the current node formatted in scheme representation
   */
  String schemeExpression();


}
