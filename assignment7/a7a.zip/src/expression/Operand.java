package expression;

import java.util.Map;

/**
 * This class represents an operand, which is either a number or a variable.
 * It is a leaf in the expression tree (i.e., no children).
 *
 */
public class Operand implements TreeNode {
  private String data;

  /** Creates an Operand node by setting input as the data field.
   * @param operand a variable or a value
   */
  protected Operand(String operand) {
    this.data = operand;
  }

  /** Calculates the value of the leaf. If the leaf contains a value, return this value.
   * If the leaf contains a variable, try to use the variable mapping input
   * to find the value to use in expression evaluation.
   *
   * @param variableValues The mapping between variables and values
   * @return The value of the leaf
   * @throws ArithmeticException If the leaf is a variable but the value of the variable
   *            isn't in the mapping input
   */
  @Override
  public double solve(Map<String, Double> variableValues) throws ArithmeticException {

    // Try to parse the data, which assumes it is a value
    try {
      return Double.valueOf(this.data);
    }

    // If the data can't be parsed into a double, then use the map value
    catch (NumberFormatException e) {
      Double answer = variableValues.get(this.data);

      // If the map doesn't map the variable to a value, throw exception
      if (answer == null) {
        throw new ArithmeticException("Expression can't be evaluated "
                + "because not all variables have been given values.");
      }
      return answer;
    }
  }

  /** Returns the current node formatted in infix representation.
   * @return the current node formatted in infix representation
   */
  public String infix() {
    return this.data;
  }

  /** Returns the current node formatted in scheme representation.
   * @return the current node formatted in scheme representation
   */
  public String schemeExpression() {
    return this.data;
  }


}
