package expression;

import java.util.Map;
import java.util.Scanner;
import java.util.Stack;


/**
 * Class represents an arithmetic expression in the form of a binary tree.
 * The root node is the last computation. Nodes can either be operands, or
 * operators (+ or - or / or *), which have children.
 */
public class ExpressionTree implements Expression {

  private TreeNode rootNode;

  private boolean checkVariableOfOneLength(Scanner input) {

    // If the scanner has a single item,
    if (input.hasNext()) {
      String token = input.next();

      if (!input.hasNext()) {

        // And if the token is a value
        try  {
          Double.parseDouble(token);
          Operand singleValue = new Operand(token);
          this.rootNode = singleValue;
          return true;
        }
        catch (NumberFormatException e) {

          // Or a variable
          if (!isOperator(token)) {
            Operand singleValue = new Operand(token);
            this.rootNode = singleValue;
            return true;
          }
        }

      }

    }

    return false;
  }


  /**
   * Constructs an Expression tree. The input is in postfix form.
   *
   * @param input Postfix format of an expression
   * @throws IllegalArgumentException When the input is invalid
   */
  public ExpressionTree(String input) throws IllegalArgumentException {

    // Initialize scanner object of input
    Scanner tokenList = new Scanner(input);

    if (checkVariableOfOneLength(tokenList)) {
      return;
    }

    tokenList = new Scanner(input);

    // Initialize stack of data and useful variables for stack manipulation
    Stack<TreeNode> stackOfNodes = new Stack<>();
    TreeNode leftNode;
    TreeNode rightNode;



    // While the scanner has more to read,
    while (tokenList.hasNext()) {
      String token = tokenList.next();

      // If it is an operand, make an operand node and push it to the stack
      if (!isOperator(token)) {

        TreeNode operand = new Operand(token);

        stackOfNodes.push(operand);
      }

      // If it is an operator, create the node with its children
      else {

        // Pops the two top-most operands which will be the children of the current operator.
        // Throw an error if those two operands never existed
        if (stackOfNodes.empty()) {
          throw new IllegalArgumentException("Failure: Not enough operands.");
        }

        rightNode = stackOfNodes.pop();
        if (stackOfNodes.empty()) {
          throw new IllegalArgumentException("Failure: Not enough operands.");
        }
        leftNode = stackOfNodes.pop();

        // Create the operator node using the items from the stack
        TreeNode operator = new Operator(token, leftNode, rightNode);

        //Push newNode to the stack
        stackOfNodes.push(operator);
      }
    }

    // If there ends up being no operator in the stack at the end of parsing, then there is an issue
    if (stackOfNodes.isEmpty()) {
      throw new IllegalArgumentException("Input expression missing operator or operand");
    }

    // Set the root node as the final operator in the postfix input
    this.rootNode = stackOfNodes.pop();

    // If the root node is an operand, then the input wasn't correct
    if (this.rootNode instanceof Operand) {
      throw new IllegalArgumentException("Not enough operators.");
    }

    // If there's still something in the stack, there weren't enough operators
    if (!stackOfNodes.isEmpty()) {
      throw new IllegalArgumentException("Too many operands or not enough operators.");
    }
  }


  /**
   * There are four valid binary operators for this assignment, + - / *. This returns true if the
   * input is one of those, false otherwise.
   *
   * @param input the questionable operator
   * @return true if valid, false otherwise
   */
  private boolean isOperator(String input) {
    return (input.equals("+") || input.equals("/") || input.equals("*") || input.equals("-"));
  }


  /** Traverses through the tree to return the tree's expression in infix form.
   * @return a string of the expression in infix form
   */
  @Override
  public String infix() {
    return this.rootNode.infix();
  }

  /**
   * Input parameter contains values of variables found in the expression tree. This method returns
   * the value of the expression, computed with the given value of variables.
   *
   * @param variableValues values of variables found in the expression tree
   * @return The value of the expression
   * @throws ArithmeticException If there was an issue with the value map inputs
   */
  @Override
  public double evaluate(Map<String, Double> variableValues) throws ArithmeticException {

    return this.rootNode.solve(variableValues);
  }

  /**
   * Turns the Expression into a String in the format of functional programming language Scheme. In
   * Scheme, and expression starts with an operator and then the operands in that order, and is
   * surrounded by parentheses.
   *
   * <p>e.g., 1 - 3 * 2 becomes (- 1 (* 3 2))</p>
   *
   * @return The String representation in Scheme of this expression
   */
  @Override
  public String schemeExpression() {
    return this.rootNode.schemeExpression();
  }
}
