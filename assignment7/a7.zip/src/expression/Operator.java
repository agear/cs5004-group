package expression;

import java.util.Map;

/**
 * TODO Add javadoc
 */
public class Operator implements TreeNode  {
  private TreeNode left;
  private TreeNode right;
  private String data;

  public Operator(String input, TreeNode left, TreeNode right) {
    this.data = input;
    this.left = left;
    this.right = right;
  }


  /** Does math within the class - simple arithmetic.
   * @param a first operand
   * @param b second operand
   * @return result of operand's calculation on two inputs
   * @throws ArithmeticException If operand isn't +/- etc
   */
  private double evaluate(double a, double b) throws ArithmeticException {

    if (this.data.equals("+")) {
      return a + b;
    }

    else if (this.data.equals("-")) {
      return a - b;
    }

    else if (this.data.equals("*")) {
      return a * b;
    }

    else if (this.data.equals("/")) {
      return a / b;
    }

    throw new ArithmeticException("Illegal operator detected.");

  }

  /** Calculates the result of the current node.
   * It does this by solving the results of its two children solved.
   *
   * @param variableValues The mapping between variables and values
   * @return result of evaluating current node arithmetically
   */
  public double solve(Map<String, Double> variableValues) {
    double leftSolved = this.left.solve(variableValues);
    double rightSolved = this.right.solve(variableValues);
    return this.evaluate(leftSolved,rightSolved);

  }


  /** Returns the current node formatted in infix representation.
   * @return the current node formatted in infix representation
   */
  public String infix() {
    return "( " + this.left.infix() + " " + this.data + " " + this.right.infix() + " )";
  }

  /** Returns the current node formatted in scheme representation.
   * @return the current node formatted in scheme representation
   */
  public String schemeExpression() {
    return "(" + this.data + " " + this.left.schemeExpression() + " " + this.right.schemeExpression() + ")";
  }


}
